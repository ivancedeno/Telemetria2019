package com.example.estudiante.app_pingui_g10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;



public class menu extends AppCompatActivity {
    String token = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Intent login = getIntent();
        this.token = (String)login.getExtras().get("token");
    }
    public void Salir(View v){
        this.finish();
        System.exit(0);
    }
    public void revisarTemperatura(View v){
        Intent temp = new Intent(getBaseContext(),
                temp.class);
        temp.putExtra("token", token);
        startActivity(temp);
    }
}